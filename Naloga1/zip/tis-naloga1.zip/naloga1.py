import json
from pathlib import Path


def encode(vhod: list) -> tuple[list, list]:
    """
    Izvede kodiranje vhodnega sporocila z algoritmom BPE.

    Parameters
    ----------
    vhod : list
        Seznam vhodnih znakov ASCII.

    Returns
    -------
    (izhod, izhodS) : tuple[list, list]
        izhod : list
            Kodirano vhodno sporocilo v obliki indeksov.
        izhodS : list
            Seznam ASCII kod in parov indeksov.
    """
    izhod = []
    izhodS = []
    return (izhod, izhodS)


def decode(vhod: list, S: list) -> list:
    """
    Izvede dekodiranje vhodnega zaporedja indeksov z algoritmom BPE.

    Parameters
    ----------
    vhod : list
        Seznam vhodnih indeksov.
    S : list
        Seznam ASCII kod in parov indeksov.

    Returns
    -------
    izhod : list
        Dekodirano vhodno sporocilo v obliki ASCII znakov.
    """
    izhod = []
    return izhod


def compute_compression_ratio(vhod: list, izhod: list ) -> float:
    """
    Izracuna kompresijsko razmerje.

    Parameters
    ----------
    vhod : list
        Vhodno zaporedje.
    izhod : list
        Izhodno zaporedje.
    

    Returns
    -------
    R : float
        Kompresijsko razmerje.
    """
    R = float("nan")
    return R


def read_raw_text(path: str) -> list:
    """
    Prebere besedilno datoteko in vrne seznam znakov.

    Parameters
    ----------
    path : str
        Pot do vhodne datoteke .txt.

    Returns
    -------
    list
        Seznam znakov iz datoteke.
    """
    return list(Path(path).read_text(encoding="ascii"))


def write_raw_text(path: str, znaki: list) -> None:
    """
    Zapise seznam znakov v besedilno datoteko.

    Parameters
    ----------
    path : str
        Pot do izhodne datoteke .txt.
    znaki : list
        Seznam znakov za zapis.
    """
    Path(path).write_text("".join(znaki), encoding="ascii")


def read_coded_msg(path: str) -> tuple[list, list]:
    """
    Prebere JSON datoteko z izhodoma funkcije encode.

    Parameters
    ----------
    path : str
        Pot do vhodne datoteke .json.

    Returns
    -------
    tuple[list, list]
        Par seznamov (izhod, izhodS).
    """
    data = json.loads(Path(path).read_text(encoding="ascii"))
    return data["izhod"], data["izhodS"]


def write_coded_msg(path: str, izhod: list, izhodS: list) -> None:
    """
    Zapise izhoda funkcije encode v JSON datoteko.

    Parameters
    ----------
    path : str
        Pot do izhodne datoteke .json.
    izhod : list
        Kodirano sporocilo.
    izhodS : list
        Seznam ASCII kod in parov indeksov.
    """
    data = {
        "izhod": izhod,
        "izhodS": izhodS,
    }
    Path(path).write_text(
        json.dumps(data, ensure_ascii=False, indent=4),
        encoding="ascii",
    )
